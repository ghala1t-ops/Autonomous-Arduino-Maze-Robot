#include <Wire.h>

// --------- Ultrasonic pins ----------
const int TRIG_FRONT = 9;
const int ECHO_FRONT = 8;
const int TRIG_RIGHT = 7;
const int ECHO_RIGHT = 6;

// --------- IR sensor pins -----------
const int IR_LEFT   = 2;
const int IR_CENTER = 3;
const int IR_RIGHT  = 4;

// --------- MPU6050 ------------------
const int MPU_ADDR = 0x68; // I2C address

float accX, accY, accZ;

// ---------- Helper: ultrasonic distance ----------
float getDistanceCM(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  unsigned long duration = pulseIn(echoPin, HIGH, 30000); // 30ms timeout
  if (duration == 0) {
    return -1.0; // no echo
  }
  float distance = duration * 0.0343 / 2.0; // speed of sound
  return distance;
}

// ---------- Helper: read MPU6050 accel ----------
void readMPU6050() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B); // starting register for accel
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDR, 6, true); // read 6 bytes (X,Y,Z)

  int16_t rawAX = (Wire.read() << 8) | Wire.read();
  int16_t rawAY = (Wire.read() << 8) | Wire.read();
  int16_t rawAZ = (Wire.read() << 8) | Wire.read();

  accX = rawAX / 16384.0; // g units
  accY = rawAY / 16384.0;
  accZ = rawAZ / 16384.0;
}

void setupMPU6050() {
  Wire.begin();
  // wake up MPU6050
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B); // PWR_MGMT_1
  Wire.write(0);    // set to zero (wakes up the MPU-6050)
  Wire.endTransmission(true);
}

// ------------------------------------
void setup() {
  Serial.begin(9600);

  pinMode(TRIG_FRONT, OUTPUT);
  pinMode(ECHO_FRONT, INPUT);
  pinMode(TRIG_RIGHT, OUTPUT);
  pinMode(ECHO_RIGHT, INPUT);

  pinMode(IR_LEFT, INPUT);
  pinMode(IR_CENTER, INPUT);
  pinMode(IR_RIGHT, INPUT);

  setupMPU6050();

  Serial.println("Sensors init done.");
}

// ------------------------------------
void loop() {
  // --- Read ultrasonic sensors ---
  float frontDist = getDistanceCM(TRIG_FRONT, ECHO_FRONT);
  float rightDist = getDistanceCM(TRIG_RIGHT, ECHO_RIGHT);

  // --- Read IR sensors (0 or 1) ---
  int irL = digitalRead(IR_LEFT);
  int irC = digitalRead(IR_CENTER);
  int irR = digitalRead(IR_RIGHT);

  // --- Read accelerometer ---
  readMPU6050();

  // --------- Print all data ----------
  Serial.println("========== SENSOR DATA ==========");
  Serial.print("Front distance: ");
  if (frontDist < 0) Serial.println("No echo");
  else {
    Serial.print(frontDist); Serial.println(" cm");
  }

  Serial.print("Right distance: ");
  if (rightDist < 0) Serial.println("No echo");
  else {
    Serial.print(rightDist); Serial.println(" cm");
  }

  Serial.print("IR Left: ");   Serial.print(irL);
  Serial.print("  IR Center: "); Serial.print(irC);
  Serial.print("  IR Right: ");  Serial.println(irR);

  Serial.print("Accel X: "); Serial.print(accX, 2);
  Serial.print("  Y: ");     Serial.print(accY, 2);
  Serial.print("  Z: ");     Serial.println(accZ, 2);

  // --------- Example: decision logic (no motors) ----------
  if (frontDist > 0 && frontDist < 20) {
    Serial.println("Decision: Obstacle ahead -> TURN RIGHT");
  } else if (rightDist > 0 && rightDist < 15) {
    Serial.println("Decision: Wall on right -> KEEP LEFT");
  } else {
    Serial.println("Decision: PATH CLEAR -> GO FORWARD");
  }

  Serial.println("=================================\n");
  delay(500); // update every 0.5 s
}
